const pino = require('pino');

module.exports = pino({});
